package com.iea.ja.service;

import java.util.Map;

public interface MemberService {

	int join(Map<?, ?> paramMap) throws Exception;

	Map<String, Object> login(Map<?, ?> paramMap) throws Exception;

	public Map<String, Object> getMember(Map<?,?> paramMap) throws Exception;
}
