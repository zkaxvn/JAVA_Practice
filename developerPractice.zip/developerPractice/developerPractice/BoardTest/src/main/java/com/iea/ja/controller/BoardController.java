package com.iea.ja.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iea.ja.common.PageInfo;
import com.iea.ja.common.Pagination;
import com.iea.ja.dao.Dao;
import com.iea.ja.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	BoardService service;
	
	@RequestMapping(value = "/boardList", method = RequestMethod.GET)
	public ModelAndView boardList(ModelAndView mv, HttpSession session,
			@RequestParam(value="page", required = false) Integer page,
			@RequestParam(value = "keyWord", defaultValue ="") String keyWord, //jsp에서 입력받은keyWord 가져옴
			@RequestParam(value = "select", defaultValue="id") String select
			) throws Exception {
		//쿼리로 담아갈 데이터맵
		Map<String, Object> paramMap = new HashMap<String, Object>();
		
		// 현재 페이지
		int currentPage = (page != null) ? page : 1;
		
		// 한 페이지당 보여줄 row
		int boardLimit = 5;
		
		//검색키워드
		paramMap.put("keyWord", keyWord); // 가져온 keyWord 파람맵에 넣어줌
		paramMap.put("select", select);//?질문하기
	
		
		// 상위 리스트 카운트
		int listCount = service.getNoticeListCount(paramMap); // +
		PageInfo pi = Pagination.getPageInfo(currentPage, listCount, boardLimit); //+
		List<Map<String, Object>> boardList = service.boardList(pi, paramMap); // pi 추가 
		if (boardList != null) {
			mv.addObject("boardList", boardList);	// 기존
			mv.addObject("startPage", pi.getStartPage());
			mv.addObject("endPage", pi.getEndPage());
			mv.addObject("currentPage", currentPage);
			mv.addObject("maxPage", pi.getMaxPage());
			mv.addObject("select", select);
			mv.addObject("keyWord", keyWord); // 서비스에서 받아온것을 모델앤뷰에 넣어줌
			
		}
		mv.setViewName("board/boardList");
		return mv; 
	}
	
	@RequestMapping(value = "/boardWriteForm", method = RequestMethod.GET)
	public String boardWriteForm() {
		return "board/boardWrite";
		
	}
	
	@RequestMapping(value="/boardWrite", method = RequestMethod.POST)
	public ModelAndView boardWrite(ModelAndView mv, 
			@RequestParam(value ="noticeTitle", required = false) String notice_title,
			@RequestParam(value = "noticeCont", required =false) String notice_cont,
			@RequestParam(value = "noticeSort", required=false) String notice_sort) throws Exception{
		Map<String, Object> paramMap = new HashMap<String, Object>();
		System.out.println(notice_title);
		System.out.println(notice_cont);
		System.out.println(notice_sort);
		paramMap.put("notice_title", notice_title);
		paramMap.put("notice_cont", notice_cont);
		paramMap.put("notice_sort", notice_sort);
		//임시 아이디
		paramMap.put("member_id", "admin");
		
		int result = service.boardWrite(paramMap);
		mv.setViewName("redirect:/boardList");
		//mv.setViewName("board/boardList");
		return mv;
		
		
		
	}
	
	// 게시물 상세 페이지로 이동
	@RequestMapping(value = "/boardDetail", method = RequestMethod.GET)
	public ModelAndView detail(ModelAndView mv, @RequestParam(value = "noticeSeq", required = false) String notice_seq)
			throws Exception {
		
		Map<String, Object> paramMap = new HashMap<String, Object>();//파람맵을 쓰려고 새로 선언한거
		paramMap.put("notice_seq", notice_seq);//파람맵에 파라미터로 받은 seq를 넣어둔거
		Map<String, Object> detail = service.getdetail(paramMap);//디테일을 조회하려고 조건에 필요한 seq가 담긴 파램맵을 보내서 조회를해서 detail에 담은거
		mv.addObject("detail", detail); //데이터꺼내와서 넣어둔 detail을 detail에 담아서 앞단으로 보낸거

		mv.setViewName("board/detail"); //내가 이걸 다 실행하고 어떤페이지를 보여줄지 저장한거 
		return mv;
	}
	

	

	// 상세 페이지에서 수정 페이지 출력
	@RequestMapping(value = "/boardModifyForm", method = RequestMethod.GET)
	public ModelAndView boardModifyForm(ModelAndView mv, @RequestParam(value = "noticeSeq", required = false) String notice_seq)
		throws Exception {
		
		Map<String, Object> paramMap = new HashMap<String, Object>();//파람맵을 쓰려고 새로 선언한거
		paramMap.put("notice_seq", notice_seq);//파람맵에 파라미터로 받은 seq를 넣어둔거
		Map<String, Object> detail = service.getdetail(paramMap);//디테일을 조회하려고 조건에 필요한 seq가 담긴 파램맵을 보내서 조회를해서 detail에 담은거
		mv.addObject("detail", detail); //데이터꺼내와서 넣어둔 detail을 detail에 담아서 앞단으로 보낸거

		mv.setViewName("board/boardModify"); //내가 이걸 다 실행하고 어떤페이지를 보여줄지 저장한거 
		return mv;
	}
	
	@RequestMapping(value="/boardModify", method = RequestMethod.POST)
	public ModelAndView boardModify(ModelAndView mv,
			@RequestParam(value ="noticeTitle", required=false) String notice_title,
			@RequestParam(value ="noticeCont", required=false) String notice_cont,
			@RequestParam(value ="noticeSeq", required=false) String notice_seq
			) throws Exception{
		Map<String, Object> paramMap = new HashMap<String, Object>();
		System.out.println(notice_title);
		System.out.println(notice_cont);
		System.out.println(notice_seq);
		
		paramMap.put("notice_title", notice_title); //  (키 값, value 값)
		paramMap.put("notice_cont", notice_cont);
		paramMap.put("notice_seq", notice_seq);
	
		//임시 아이디
		//paramMap.put("member_id", "admin" );
		
		int result = service.boardModify(paramMap);
		mv.setViewName("redirect:/boardList");
		return mv;
	}		
	
	/*
	@RequestMapping(value= "/boardDelete", method = RequestMethod.GET )
	public String boardDelete( ModelAndView mv,
			@RequestParam(value="noticeSeq", required= false) int notice_seq ) throws Exception {
		Map<String, Object> paramMap = new HashMap<String, Object>(); 
		System.out.println(notice_seq);
		
		paramMap.put("notice_seq" , notice_seq);
	
		int result = service.boardDelete(paramMap);
		
		return "redirect:/boardList";
	}
	*/	
	
//	@RequestMapping(value = "/deleteNotice", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
//	@ResponseBody
//	public String deleteNotice(HttpServletRequest request) throws Exception {
//		Map<String, Object> paramMap = new HashMap<String, Object> ();
//		ObjectMapper mapper = new ObjectMapper();
//		//ObjectNode obj = mapper.createObjectNode();
//		
//		int notice_seq = Integer.parseInt(request.getParameter("notice_seq"));
//		
//		paramMap.put("notice_seq", notice_seq);
//		
//		//int result = service.deleteNotice(paramMap);
//		
//		if(result > 0 ) {
//			obj.put("result" ,true);
//		}else {
//			obj.put("result", false);
//		}
//		return obj.toString();
//	}
	

	
/*
	@RequestMapping(value ="/boardUpdate", method = RequestMethod.GET)
	public ModelAndView boardUpdate(ModelAndView mv, 
			@RequestParam(value = "noticeSeq", required = false) String notice_seq,
			@RequestParam(value ="noticeTitle", required = false) String notice_title, //왜 앞에는 camel 문자형식인지
			@RequestParam(value = "noticeCont", required =false) String notice_cont) throws Exception {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		if (notice_seq.equals("")) {
			paramMap.put("notice_seq", null); // ㅋㅋㅋㅋ ㅠㅠ 구롬 이건 맞아여?
		}else {
			paramMap.put("notice_seq" , notice_seq);
		} // type변수 설정 때문에 들어있는 코드일까요?? - Q1
		 
		paramMap.put("notice_title", notice_title);
		paramMap.put("notice_cont", notice_cont);
		
		//int result = service.boardUpdate(paramMap);
		mv.addObject("update",service.boardUpdate(paramMap)); //그럼 이거 완전  틀린 거네여이제라도 알아서 다행이네요
		mv.setViewName("board/boardUpdate");
		
		return mv;
	}
*/
	
/*	
	@RequestMapping(value ="/boardDelete" , method = RequestMethod.GET)
	public ModelAndView boardDelete(ModelAndView mv, @RequestParam(value = "noticeSeq", required = false) String notice_seq)
			throws Exception {
		// HttpServletRequset ->?
		Map<String, Object> paramMap = new HashMap<String, Object>();
		int cnt = service.boardDelete(paramMap);
		return mv;
	}
*/			
	
	/*
	public ModelAndView boardList() throws Exception{
		List<BoardDto> list = boardService.listAll();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("board/list"); //뷰를 list.jsp에 저장
		mv.addAllObject("list", list); // 데이터를 저장
		return mv;
	}
	
	
	// 게시글 작성화면
	@RequestMapping(value ="/boardWrite", method = RequestMethod.GET)
	public String write() {
		return "board/write"; //write.jsp 로 이동
		
	}
	
	//게시글 작성처리
	
	public String insert(@ModelAttribute BoardDto dto) throws Exception{
		boardService.create(dto);
		return "redirect:list"; // redirect?
	}
	*/
}
