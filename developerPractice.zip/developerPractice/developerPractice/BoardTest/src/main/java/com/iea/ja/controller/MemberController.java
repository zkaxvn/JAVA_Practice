package com.iea.ja.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.iea.ja.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	MemberService service;
	
	@RequestMapping(value="/join", method=RequestMethod.POST)
	public ModelAndView join (ModelAndView mv,
			@RequestParam(value= "memberId") String member_id,
			@RequestParam(value ="memberPw") String member_pw,
			@RequestParam(value= "userName") String user_name) throws Exception {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		System.out.println("member_id:"+ member_id);
		System.out.println("member_pw:"+ member_pw);
		System.out.println("user_name" + user_name);
		
		paramMap.put("member_id", member_id);
		paramMap.put("member_pw", member_pw);
		paramMap.put("user_name", user_name);
		
		service.join(paramMap); 
		mv.setViewName("home");
		//mv.setViewName("board/boardList");
		return mv;
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView login(ModelAndView mv, HttpSession session,
			@RequestParam(value= "memberId") String member_id, //required = false : 필수 여부
			@RequestParam(value ="memberPw") String member_pw) throws Exception {
		Map <String, Object> paramMap = new HashMap<String, Object>();
		
		paramMap.put("member_id", member_id);
		paramMap.put("member_pw", member_pw);
		//String memberId = service.login(paramMap);
		//String memberPw = service.login(paramMap);
		
		Map <String, Object> loginUserMap = service.login(paramMap);
		if (loginUserMap!= null && !loginUserMap.toString().equals("")) { //toStirng
			session.setAttribute("loginUserMap", loginUserMap);
			mv.setViewName("home");
		} else {
			mv.addObject("msg", "아이디 비밀번호를 확인하세요.");
			mv.setViewName("member/login");
		}
		System.out.println(member_id);
		System.out.println(member_pw);
		return mv;

	}
	
	@ResponseBody
	@RequestMapping(value = "/idCheck", method = RequestMethod.GET)
	public String idCheck(HttpServletRequest request) throws Exception {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		String result = ""; //??
		
		String id = request.getParameter("id");  //ajax data 의 키값 :id
		paramMap.put("member_id", id); //요청받은 id 를 member_id라는 키값으로 파람맵에 넣기
		System.out.println(id);
		
		Map<String, Object> userInfo = service.getMember(paramMap);
		
		if (userInfo != null) {
			result = "false";
		} else {
			result = "true";
			
		} return result;
	}
}
