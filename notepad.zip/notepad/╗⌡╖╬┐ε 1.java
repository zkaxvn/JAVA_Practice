/*둘 이상의 페이지 요청에서 사용자를 식별하거나, 웹 사이트를 방문하고 해당 사용자에 대한 정보를 저장하는 방법을 제공한다.

서블릿 컨테이너는 HttpSession 인터페이스를 사용하여 Http 클라이언트와 HTTP 서버 간의 세션을 작성합니다. 세션은 지정된 시간 동안 
사용자의 둘 이상의 연결 또는 페이지 요청에 걸쳐 지속됩니다. 세션은 일반적으로 사이트를 여러 번 방문할 수 있는 한 사용자에 해당합니다. 
서버는 쿠키를 사용하거나 URL을 다시 작성하는 등의 다양한 방법으로 세션을 유지관리할 수 있습니다.

세션 정보는 현재 웹 응용프로그램( ServletContext) 으로만 범위가 지정되므로, 한 컨텍스트에 저장된 정보는 다른 컨텍스트에서 직접 볼 수 없습니다.


HttpSession.setAttribute("user", user) // set attribute 사용해서 user
httpSession.getAttribute("user")
httpSession.invalidate()
*/

// key 값, value 값

// setAttribute를 사용해서 user를 세션에 저장하고 getAttribute를 사용해서 다시 user를 꺼내올 수 있다.
// invalidate를 통해서 세션을 제거할 수 있다.

// HttpSession

// Map 인터페이스의 경우 HashMap<K,V> 묶어 하나의 Entry 형식으로 저장된다

public class TestGo{

	public static void main(String[] args) {
	
	//map <key, value> value의 자료형이 Object라 모든 Object는 다 들어갈 수 있다.
	Map<String, Object> map = new HashMap<String, Object>(); 
	// Map Object를 <String, Object>형식으로 선언 
	
	//Map에 문자열 데이터를 넣는다.
	map.put("testSTr", "테스트 데이터 입니다.");
	// map의 put 메소드를 사용하여 (key : value) 형식으로 데이터를 저장합니다.
	
	//Map에 정수 데이터를 넣는다.
	map.put ("testInt", 1234567890);
	
	//저장할때 쓴 Key를 사용하여 Value를 불러옵니다.
	System.out.println("문자열 데이터 표출 : " + map.get("testStr"));
	System.out.println("정수 데이터 표출 : " + map.get("testInt"));
	
	
	// Value의 자료형을 불러 옵니다.
	System.out.println("자료형 :: " + map.get("testStr").getClass().getName());
	System.out.println("자료형 :: " + map.get("testInt").getClass().getName());
	
	// map 데이터를 문자열에 셋팅
	String setStr = map.get("testStr").toString(); 
	//key(testStr)에 저장된 Value(테스트 데이터 입니다.)를 String(문자열)에 Set합니다.
	// toString(?
	
	// map 데이터를 int에 셋팅
	int setInt = (int)map.get("testInt");
        
   }
    
}


