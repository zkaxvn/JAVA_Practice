세션과 쿠키 (session, cookie)

웹 서비스는 http 프로토콜을 기반으로 사용자와 통신
Http 프로토콜은 클라이언트와 서버와의 관계를 유지하지 않는 특징은 stateless 기반 프로토콜

만약 쇼핑몰같은 웹서비스를 이용할 때 만약 http 프로토콜만으로 통신한다면 페이지 이동 마다 서버와 연결해야 하는 불편함이 생긴다.
또 사용자의 요청마다 서버와 매번 새로운 연결이 생기기 때문에 로그인 상태유지, 장바구니 등의 기능을 구현하는 것이 매우 까다로워 진다.

이런 stateless 상태를 해결하는 두 가지 방식이 있는데, 세션(Session)과 쿠키(cookie)
두 방식 모두 사용자와 서버의 연결 상태를 유지해주는 방법, 세션은 서버에서 연결 정보를 관리하는 반면 쿠키는 사용자 측에서 
연결 정보를 관리하는 데 차이가 있다.

세션 (session)을 구현하기 위한 HttpServletRequest 사용

- 스프링 mvc 에서 세션은 HttpServletRequest 혹은 HttpSession을 사용해서 구현할 수 있다.
여기서는 HttpServletRequest를 통한 세션 생성방법을 알아보겠다.

@RequestMapping(value= "/modify", method = RequestMethod.POST)
public ModelAndView modify( Member member, HttpServletRequest request) {

	HttpSession session = request.getSession();
	
	Member mem = service.memberModify(member);
	session.setAttribute("member", mem);
	
	ModelAndView mv = new ModelAndView();
	mv.addObject("memAft", mem);
	mv.setViewName("/member/modifyOk");
	
	return mv;
}
-> 사용자 정보를 변경하는 요청인 /modify으로 요청이 들어오면 HttpServletRequest 객체인 request가 인자로 들어오면서
modify 메서드가 실행

이 때 세션에 setAttribute메서드를 통해 세션의 속성값을 설정한다
이 속성값은 세션에 의해 유지되며 getAttribute 메서드를 통해 다른 요청을 처리하는 컨트롤러 메서드에서 이 값을 얻을 수 있다.

@RequestMapping(value= "/modifyForm", method = RequestMethod.GET)
public ModelAndView modifyForm(HttpServletRequest request) {
	
	HttpSession session = request.getSession();
	Member member = (Member) session.getAttribute("member");
	
	ModelAndView mv = new ModelAndView();
	mv.addObject("member", service.memberSearch(member));
	
	mv.setViewName("/member/modifyForm");
	
	return mv;
}

getSession 메서드를 통한 HttpSession 객체를 하나 생성하여 간단히 세션을 구하고 이 세션이 붙들고 있는 속성값을 얻을 수 있다.
이후에 /modifyForm 요청이 들어오면 사용자의 정보를 기억하고 그 결과를 JSP파일로서 반환하게 된다.

사용자의 세션을 끊고 싶으면 아래와 같은 방식으로 세션을 삭제하면 된다.
@RequestMapping(value= "/remove", method = RequestMethod.POST)
public String memRemove(Member member, HttpServletRequest request){
	
	service.memberRemove(member);
	
	HttpSession session = request.getSession();
	session.invalidate();
	
	return "/member/removeOk";
}

/remove는 로그아웃을 하라는 요청을 나타내는 url이다.
request 객체의 세션을 얻은 후 그 세션을 invalidate 메서드로 비활성화 시키면 세션이 끊긴다(로그아웃 됨)
이때부터 웹사이트에 연결이 되도 새로운 사용자 정보를 통해 로그인을 해야한다.

쿠키(Cookie)를 구현하기 위한 Cookie 객체 생성 및 @CookieValue 어노테이션

스프링 mvc에서 쿠키를 생성하는 방법
public class Mail {
	
	private String gender;
	private boolean cookieDel;
	
	public String getGender() {
		return gender;
	}
	
	publice void setGender(String gender) {
		return cookieDel;
	}
	public void setCookieDel(boolean cookieDel) {
		this.cookieDel = cookieDel;
	}
}

@RequestMapping
	

 