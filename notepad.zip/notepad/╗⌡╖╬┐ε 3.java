1. 모델(Model) : 비즈니스 규칙을 표현

2. 뷰(View) : 프레젠테이션을 표현

3. 컨트롤러(Controller) : 위 두가지를 분리하기 위하여 양측 사이에 배치된 인터페이스.

​
Controller 의 두가지 역할
주로 사용자의 요청을 처리 한 후 지정된 뷰에 모델 객체를 넘겨주는 역할을 수행한다,
지정된 뷰에 모델 객체를 넘겨주는 역할은 두가지로 나누어 설명 가능

1. 사용자들이 웹브라우저에서 'URI*'로 요청을 보내면, 그 요청을 컨트롤러가 받게 된다.
2. 요청에 대한 응답(view)을 반환한다.

URI?

URL : Uniform Resource Locator
- locator
:자원을 '서버에 있는 폴더' 위치로 찾아간다.
ex) web/app/...

URI : Uniform Resource Identifier
- id
:위치로 찾아가게 하는 것이 아니라, 아이디로 매핑시켜놓는다. 따라서 사용자에게 파일 이름, 위치 노출이 되지 않는다.
(그래서 컨트롤러를 만든다는 말은 곧 URI를 만든다는 말)

스프링 MVC컨트롤러
기본적인 흐름은 client가 요청을 하면, @Controller에 진입한다.
컨트롤러는 요청에 대한 작업을 수행하고, 뷰쪽으로 데이터를 전달한다.

컨트롤러 클래스 제작 순서
@Controller 를 이용해서 클래스를 생성
@RequestMapping을 이용해, view의 요청 경로 지정
요청 처리 메소드(로직) 구현
뷰 이름 리턴

@Controller // 컨트롤러 지정
public class HomeController {
    
    // 뷰의 요청 경로 지정
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String home(Locale locale, Model model) {
        
        // 로직 수행
        logger.info("Welcome home! The client locale is {}.", locale);
        Date date = new Date();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
        String formattedDate = dateFormat.format(date);
        
        // Model 객체를 이용해서, view로 Data 전달
        model.addAttribute("serverTime", formattedDate );
        
        return "home"; // 뷰 파일 리턴
    }
}

view 의 요청 경로 (Path) 설정하기
@RequestMapping
어노테이션을 이용해서, view 폴더안의 내가 목표로 하는 view의 경로(path)를 넣는다.



출처: https://hongku.tistory.com/116 [IT에 취.하.개.:티스토리]