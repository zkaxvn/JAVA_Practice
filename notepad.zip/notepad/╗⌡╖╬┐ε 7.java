1) MyBatisController.java

@Controller
public class MyBatisController {

	@RequestMapping(value = "/m1.action", method = { RequestMethod.GET })
	public String m1(HttpServletRequest req, HttpServletResponse resp, HttpSession session) {
		
		MyBatisDTO dto = new MyBatisDTO();
		
		dto.setSeq("3");
		dto.setName("김홍삼");
		dto.setMemo("메모입니당.");
		dto.setCategory("Mybatis");
		
		// 반환값이 없는 쿼리(insert, update, delete)
		int addResult = dao.add();
		int delResult = dao.del();
		int updateResult = dao.update(dto);
		
		req.setAttribute("addResult", addResult);
		req.setAttribute("delResult", delResult);
		req.setAttribute("updateResult", updateResult);
		
		return "result";
	}

}

2) MyBatisDTO
import lombok.Data;

@Data
public class MyBatisDTO {
	private String seq;
	private String name;
	private String memo;
	private String regdate;
	private String category;
}

3) MyBatisDAO
@Repository
public class MyBatisDAO {

	@Autowired
	private SqlSessionTemplate template; // Statement + ResultSet + Mapping

	// 반환값이 없는 쿼리 > insert, delete, update
	// template.insert("")      : 인자가 없는 쿼리 
	// template.insert("", obj) : 인자가 있는 쿼리
	
	public int add() {
		// 매개변수가 없는 반환값 없는 쿼리
		return template.insert("test.m1");
	}
	
	public int del() {
		// 매개변수가 있는 반환값 없는 쿼리
		return template.delete("test.m2", 5);
	}
	
	public int update(MyBatisDTO dto) {
		// 매개변수가 있는 반환값 없는 쿼리
		return template.update("test.m3", dto);
	}
}

  4) test.xml
  MyBatis에서는 SQL구문을 xml파일에서 따로 형식에 맞게 작성한다.

  - 매개변수가 넘어 올 때는 반드시 parameterType으로 자료형을 설정해야한다.

  - 매개변수는 #{ } 형식으로 나타낸다. (호따옴표 사용 NO!!)
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">

<mapper namespace="test">
	
	<!--  
		<insert id=""></insert>
		<update id=""></update>
		<delete id=""></delete>
		<select id=""></select>
	-->
	
<!-- add -->
	<insert id="m1">
		insert into tblMemo (seq, name, memo, regdate, category)
			values (seqMemo.nextVal, '홍길동', 'MyBatis 테스트', default, 'mybatis')
	</insert>
	
	<!-- delete -->
	<delete id="m2" parameterType="Integer">
		delete from tblMemo where seq = #{ seq }
	</delete>
	
	<update id="m3" parameterType="com.test.spring.mybatis.MyBatisDTO">
		update tblMemo set
			name = #{ name }, <!-- 넘어온 getName()을 name으로 줄여준다. -->
			memo = #{ memo }, <!--  어떤 자료형이든 호따옴표를 절대 붙이면 안된다.!! -->
			category = #{ category }
		where seq = #{ seq }
	</update>
	
</mapper>


5) result.jsp
- 눈으로 결과값을 (0 or 1) 확인 하기 위한 페이지

<div>insert 작업 결과: ${ addResult }</div>
<div>delete 작업 결과: ${ delResult }</div>
<div>update 작업 결과: ${ updateResult }</div>

결과
insert 작업결과 : 1
delete 작업결과 : 1
update 작업결과 : 1

- 위에서 설정한 MyBatis를 이용한 DB작업 insert, update, delete도 SQL-Developer를 확인하면 제대로 작업이 이루어 진걸 확인할 수 있다.
- 추가로 SQL구문을 작성하는 test.xml파일에서 m3를 보면 매개변수(dto)가 넘어왔으므로 parameterType="자료형"을 지정해줘야하는데 
패키지명 까지 전부 적어줘야 적용이 된다. (여러 패키지에서 중복된 이름이 있을 수있기 때문에..)

[ parameterType Alias(별칭) 지정하기 ]

이러한 불편사항을 해결하기 위해 alias를 지정할 수 있다!

https://kyhyuk.tistory.com/141?category=1016272 : 초보 개발자가 보기 좋을 블로그