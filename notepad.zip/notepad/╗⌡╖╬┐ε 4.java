// Map HashMap 

Map 인터페이스 경우 HashMap<K,V> 을 제일 많이 사용
HashMap의 경우 Key:value를 묶어 하나의 Entry 형식으로 저장
public class TestGo {
 
    public static void main(String[] args) {
        
        // map<key : value> value의 자료형이 Object라 모든 Object는 다 들어갈수 있다.
        Map<String, Object> map = new HashMap<String, Object>();
		//-> Map Object를 <String, Object> 형식으로 선언 
        
        // Map에 문자열 데이터를 넣는다.
        map.put("testStr", "테스트 데이터 입니다.");
		//-> Map의 put 메소드를 사용하여 (Key, Value)형식으로 데이터를 저장
        
        // Map에 정수 데이터를 넣는다.
        map.put("testInt", 1234567890);
        
        System.out.println("문자열 데이터 표출 : " + map.get("testStr"));
        System.out.println("정수 데이터 표출 : " + map.get("testInt"));
		//->저장할때 쓴 Key 를 사용하여 Value를 불러옵니다.
		
        
        System.out.println("자료형 :: " + map.get("testStr").getClass().getName());
        System.out.println("자료형 :: " + map.get("testInt").getClass().getName());
        
        // map 데이터를 문자열에 셋팅
        String setStr = map.get("testStr").toString();
		//->key(testStr)에 저장된 Value(테스트 데이터 입니다.)를 String(문자열)에 Set합니다.
        
        // map 데이터를 int에 셋팅
        int setInt = (int)map.get("testInt");
		//->key(testInt)에 저장된 Value(1234567890)를 int(정수)에 Set합니다.
        
    }
    
}
 