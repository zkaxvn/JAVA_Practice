Ajax -> Asynchronous JavaScript and XML
->

cdnjs.com - > jq 라고 치면 jquery 나옴

Http 
web browser -> req -> webserver
			<-	response	<-
			
XMLHttpRequest() 
URL


jsp 파일 
<script src = "https://cdnjs.cloudflard.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
/* <script>
function callByAjax(){
	alert ('실행됨');
	}
</script>
*/
<script>
function callByAjax(){
	var form = document.form1; // document =?
	
	var num1 = form.num1.value;
	var num2 = form.num2.value;
	 
	var action = form.action;
	 
	$.get( //get 메소드 방식
		'./doPlus',
		{
			num1:num1,
			num2:num2
		},
		function(data) {
			$.('.rs').empty().append(data); 			//empty() : 기존 데이터 없애고 다시 작성
			//$.('.rs').text(data); 
		},
			'html'
	);
}