사수님 mapping 계속 오류나서 뒤지다가 parameterType = map 으로 되어있던거 resultType= map 으로 바꾸니까 오류가 안났구여, 
jsp 파일에서 ${} 안에 있는것들 detail.notice_## 으로 바꾸니까 페이지 조회 성공했는데
 jsp 자체에서 items = ${boardList} 를 var ="list"로 해놓아서 list.## 이 가능해진거임
 
MyBatis 리턴 결과 차이
select - select 문에 해당하는 결과
insert - 1(다중 insert도 마찬가지)
update - update 된 행의 갯수 반환 (없으면 0 )
delete - delete 된 행의 갯수 (없으면 0 )

parameterType ="map"
-> 쿼리에서 쓸 데이터들이 맵으로 들어옴.

DB에서 데이터 가져올 때 : select

update, insert, delete -> 대부분 숫자로 리턴

PRO - ChatController 참고

int cnt = service.updateCount(message)
if(cnt>0) {
	System.out.println("읽음 표시 완료");
	} else {
	System.out.println("실패");
	}
	
Mapper.xml 에서	
반환값이 있을 경우 resultType="자료형", select문은 무조건 resultType을 붙여야 한다.
반환값, 매개변수 둘 다 존재할 경우 둘 다 쓸것. resultType, parameterType

HttpServletRequest req, HttpServletResponse resp, HttpSession session
->  공부하기

다중 레코드 반환
주의사항!! 결과셋이 다중 레코드이지만 1개의 레코드를 담을 수 있는 자료형만 resultType에 적는다.

MyBatis (Insert, Delete, Update)
[정의]
- MyBatis 는 자바 퍼시스턴스 프레임워크의 하나로 xml 서술자나 에너테이션을 사용하여 저장 프로시저나 sql문으로 객체들을 연결시킨다.
- 예전에는 iBatis로 불리었으며, 현재는 iBatis와 MyBatis는 완전히 다른 기능을 한다.
- 응용프로그램 계층(자바) <-> 퍼시스턴스 계층(중간 계층, JDBC) <-> 데이터베이스 계층 (오라클)
- 중간 계층 기술 중 하나이다.(JDBC, MyBatis, JPA, Hibernate, Spring JDBC .. 등)
- MyBatis는 SQL 구문을 XML파일에서 작성한다. (기존에는 xxxDAO() 에서 try-catch문 안에 만들었음)'


예제 작업 전 설정 작업 ( * Log4j: 데이터베이스 작업 중 관련된 로그를 출력하는 기능 ) 
1. pom.xml
	- Java 버전에 맞게 변경
	- Spring 버전에 맞게 변경

2. lib
	- pom.xml
	- ojdbc6.jar
	- mybatis x n개
	- log4j

3. web.xml
	- 확장자 변경(*.action)
	- 인코딩 필터 추가(UTF-8)
	
4. root-context.xml
	- MyBatis 설정
	- Log4j 설정 > 추가
	
5. servlet-context.xml
	- 설정 없음

6. 파일 생성	
	- com.test.mybatis > MyBatisController.java, MyBatisDAO.java, MyBatisDTO.java
	- com.test.mybatis.mapper > test.xml
	- views > result.jsp