// ModelandView

// 기본적인 흐름은 client 가 요청을 하면, @Controller에 진입한다.
// 컨트롤러는 요청에 대한 작업을 수행하고, 뷰쪽으로 데이터를 전달한다.

// 컨트롤러 클래스 제작 순서
/*
@Controller 를 이용해서 클래스를 생성
@RequestMapping을 이용해 view의 요청 경로 지정
요청 처리 메소드(로직) 구현
뷰 이름 리턴
*/

@Controller //컨트롤러 지정
public class HomeController {
	//뷰의 요청 경로 지정
	@RequestMapping(value="/", method = RequestMethod.GET)
	public String home(Locale locale, Model model){
		
		//로직 수행
		
		//Model 객체를 이용해서, view로 Data 전달
		model.addAttribute("serverTime", formattedDate);
		
		//addAttribute (?
		
		return "home"; // 뷰 파일 리턴
	}
}

		
View의 요청 경로(Path) 설정
@RequestMapping
// 어노테이션을 이용해서 view 폴더안의 내가 목표로 하는 view 의 경로(path)를 넣는다.
// 예- view.jsp @RequestMapping("/board/view") //요청경로(path)
// return "board/view"; //뷰페이지 이름

Model 객체 사용
@RequestMapping("/board/view")
public String view(Model model) {
	
	//데이터만 설정이 가능
	model.addAttribute("id", "hongku")
	
	return "board/view";
}

Model객체를 파라미터로 받는다.
model.addAttribute("변수이름", "변수에 넣을 데이터값")

model.addAttribute를 이용해서 넘길 데이터의 이름과 값을 넣는다.
그러면, 스프링은 그 값을 뷰쪽으로 넘겨준다.

${변수이름}

뷰(.jsp 파일)에서는 ${}를 이용해서 값을 가져온다.

예- 당신의 ID는 ${id} 입니다.

ModelandView
@RequestMapping("/board/content")
public ModelandView content(){
	
	//데이터와 뷰를 동시에 설정 가능
	ModelandView mv = new ModelandView();
	mv.setViewName("/board/content"); // 뷰의 이름
	mv.addObject("data", "1023456"); // 뷰로 보낼 데이터값
	
	return mv;
	
}

반환값으로 ModelandView 객체를 반환 

ModelandView 객체를 선언 및 생성

뷰의 이름을 설정해줘야 하는데, setViewName() 메소드를 이용
mv.setViewName("뷰의 경로");

데이터를 보낼때는 addObject() 메소드를 이용한다.
mv.addObject("변수 이름", "데이터 값");

그리고,
return mv;

-> ModelandView 객체를 반환
jsp 도 똑같이 ${} 사용

Data = ${data}

출처 : https://hongku.tistory.com/116

게시판 만들기 (리스트 출력) : https://kingchobocoding.tistory.com/12

게시판 등록, 수정, 삭제, 조회 : https://gangnam-americano.tistory.com/3