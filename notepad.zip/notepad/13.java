입력 . 연산 . 출력
//1. Use Strict
//added in ES 5
//use this for Valina Javascript
'use strict';

//2. Variable
//let (added in ES6)

let name = "ellie" //메모리 안에 저장
consol.log(name);
name = "hello";
consol.log(name);

//block scope

//global scope

let globalName = "global name";
{
	let name = "ellie";
	console.log(name);
	name = "hello";
	consol.log(name);
	console.log(globalName);
}
console.log(name);
console.log(globalName);

//var
// 선언도 하기전에 값 할당 가능 -> 사용 하지 말기
// var hoisting (move declaration from bottom to top)
// has no block scope

//3. constants
-> 값이 바뀌지 않음
immutable type
// favor immutable data ype always for a few reasons:
// - security
// - thread safety
// - reduce human mistakes
const daysInWeek = 7;

//4. Varialbe types
// primitive, single item : number, string, boolean, null. undefind, Symbol
// object, box container
// function, first-class function : 변수에 할당 가능 ,함수의 파라미터 리턴 가능
값에 상관없이 number 타입

// string  '' 안에서 띄어쓰기 다 수용

//boolean
// false : 0, null, undefined, NaN, ''
// true : any other value
const canRead = true;
const test = 3<1; // false
consol.log('value: ${canRead}, type = ${typeof canRead:'); - >true
consol.log('value: ${test}, type: ${typeof test}'); -> false