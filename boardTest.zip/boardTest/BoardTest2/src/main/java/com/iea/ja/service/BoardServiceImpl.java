package com.iea.ja.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iea.ja.dao.Dao;

@Service
public class BoardServiceImpl implements BoardService{
	
	@Autowired
	private Dao dao;
	
	@Override
	public List<Map<String, Object>> boardList(Map<String, Object> paramMap) throws Exception{
		return (List<Map<String, Object>>) dao.getList("BoardMapper.boardList", paramMap);
	}
	
	@Override
	public int boardWrite(Map<?, ?> paramMap) throws Exception {
		int result = dao.insert("BoardMapper.boardWrite", paramMap);
		return result;
	}
	
	@Override
	public Map<String,Object> getdetail(Map<?,?> paramMap) throws Exception { 
		Map<String,Object> result = (Map<String,Object>) dao.getMap("BoardMapper.getdetail", paramMap); 
		// BoardMapper.<getdetail> 이랑 mapper.xml id랑 같아야함
		return result;
	}
	
	@Override
	public Map<String, Object> boardModifyForm(Map<?,?> paramMap) throws Exception {
		Map<String, Object> result = (Map<String, Object>) dao.getMap("BoardMapper.getdetail", paramMap);
		return result;
	}
	
	@Override
	public int boardModify(Map<?,?> paramMap) throws Exception {
		int result = dao.update("BoardMapper.boardModify", paramMap);
		return result;
		
	}
	
	public int boardDelete(Map<?,?> paramMap) throws Exception {
		int result = dao.delete("BoardMapper.boardDelete", paramMap);
				return result;
	}
	/*
	@Override
	public int boardUpdate(Map<?,?> paramMap) throws Exception { // ?,?를 쓰는 경우와 그렇지 않은 경우 - Q2
		int result = dao.update("BoardMapper.boardUpdate", paramMap);
		return result;
		
	}
	@Override
	public int boardDelete(Map<?, ?> paramMap) throws Exception {
		return 0;
	}
	*/
}
