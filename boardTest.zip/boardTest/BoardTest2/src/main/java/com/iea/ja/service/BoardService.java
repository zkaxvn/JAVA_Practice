package com.iea.ja.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.servlet.ModelAndView;

import com.iea.ja.dao.Dao;

public interface BoardService {

	public List<Map<String, Object>> boardList(Map<String, Object> paramMap) throws Exception;

	//void boardWrite(Dao dao) throws Exception; //게시글 등록하는 기능에 대한 서비스
	
	public int boardWrite(Map<?, ?> paramMap) throws Exception;

	Map<String, Object> getdetail(Map<?, ?> paramMap) throws Exception;
	
	//int boardUpdate(Map<?, ?> paramMap) throws Exception;
	
	//public int boardDelete (Map<?,?> paramMap ) throws Exception;

	Map<String, Object> boardModifyForm(Map<?, ?> paramMap) throws Exception;
	
	public int boardModify(Map<?,?> paramMap ) throws Exception;

	int boardDelete(Map<?,?> paramMap) throws Exception;
	
	

}
