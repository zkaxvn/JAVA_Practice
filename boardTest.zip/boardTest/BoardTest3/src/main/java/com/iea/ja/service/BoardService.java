package com.iea.ja.service;

public interface BoardService {

}
