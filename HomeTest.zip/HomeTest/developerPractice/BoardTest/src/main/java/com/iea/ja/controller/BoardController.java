package com.iea.ja.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.iea.ja.service.BoardService;

@Controller
public class BoardController {
	
/*
	@RequestMapping(value = "/boardList", method = RequestMethod.GET)
	public ModelAndView boardList(ModelAndView mv) {
		mv.setViewName("board/boardList");
		return mv;
	}
*/
	//-1. 서비스와 연결
	@Autowired
	BoardService service;
	
	//1. 리스트 출력
	// 서버의 리스트를 앞단에 보여줌
	// value = "/url"
	@RequestMapping(value="/boardList", method = RequestMethod.GET)
	public ModelAndView boardList(ModelAndView mv) throws Exception{
		Map<String, Object> paramMap = new HashMap<String, Object>(); //쿼리로 담아갈 파람맵을 선언
		List<Map<String, Object>> boardListt = service.boardList(paramMap); // service를 통해 넘겨받은 파람맵을 리스트 형태로 받아옴
		mv.addObject("boardList", boardListt); // 받아온 boardList를 "boardList" 라는 키 값으로 mv에 넣어서 노출시켜줌
		mv.setViewName("board/boardList");
		return mv;
	}
	
	// 작성 페이지 화면 출력
	@RequestMapping(value="/boardWriteForm", method = RequestMethod.GET)
	public String boardWriteForm() {
		return "board/boardWrite";
	}
	
	@RequestMapping(value="/boardWrite", method= RequestMethod.POST)
	public ModelAndView boardWrite(ModelAndView mv,
			@RequestParam(value="noticeTitle") String noticeTitle,
			@RequestParam(value="noticeCont") String noticeCont) throws Exception {
		
		mv.setViewName("redirect:/boardList");
		return mv;
	}
}
