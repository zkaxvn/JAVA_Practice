package com.iea.ja.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iea.ja.dao.Dao;

@Service
public class BoardServiceImpl implements BoardService{
	
	@Autowired
	private Dao dao;
	
	@Override
	public List<Map<String,Object>> boardList(Map<String, Object> paramMap) throws Exception {
		// mapper의 boardList 안의 쿼리문을 통하여 리스트 가져옴
		return (List<Map<String, Object>>) dao.getList("BoardMapper.boardList", paramMap);
		// 그 리스트를 파람맵의 형태로 가져옴
	}
	
	

}
