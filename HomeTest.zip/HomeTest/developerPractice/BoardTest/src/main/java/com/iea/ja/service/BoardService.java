package com.iea.ja.service;

import java.util.List;
import java.util.Map;

public interface BoardService {

	List<Map<String, Object>> boardList(Map<String, Object> paramMap) throws Exception;

}
