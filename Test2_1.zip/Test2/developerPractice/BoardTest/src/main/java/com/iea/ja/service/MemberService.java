package com.iea.ja.service;


import java.util.Map;

import com.iea.ja.vo.Member;

public interface MemberService {

	// import나 @어노테이션 해줄 거 없음 -> Map 정도만 import
	
	public int userSignUp(Member user);

	
	

}
