package com.iea.ja.controller;


import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.iea.ja.service.MemberService;
import com.iea.ja.vo.Member;

@Controller
public class MemberController {
	
	@Autowired				// service @Autowired 해주기  
	MemberService service; // MemberService import 해주기 
	
	@RequestMapping(value="/joinForm", method = RequestMethod.GET)
	public String joinForm() {
		return "/member/join";
	}
	
	@RequestMapping(value="/userSignUp", method = RequestMethod.POST) 
	public ModelAndView userSignUp(ModelAndView mv, Member user) {
		//유저 상태
		
		//비밀번호 암호화
		
		int result = service.userSignUp(user); // service의 userSignUp 만들기
		if(result > 0) {
			mv.setViewName("home");
		} else {
			mv.addObject("msg", "서버 오류! 관리자에게 문의 바랍니다.");
			mv.setViewName("/member/join");
		}
		
		return mv;
	}
}
