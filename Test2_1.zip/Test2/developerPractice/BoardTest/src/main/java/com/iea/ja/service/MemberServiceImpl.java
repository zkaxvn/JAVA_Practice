package com.iea.ja.service;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iea.ja.dao.Dao;
import com.iea.ja.dao.MemberDao;
import com.iea.ja.vo.Member;

@Service //@Service 임플에 걸어주기
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private Dao dao;
	
	@Autowired
	private MemberDao mDao;
	
	@Override
	public int userSignUp(Member user) { // Map import 해주기
		int result = mDao.userSignUp(user);
		return result;
	}

}
